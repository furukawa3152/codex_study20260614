README draft:
This folder intentionally contains messy training files for a Codex study session.
